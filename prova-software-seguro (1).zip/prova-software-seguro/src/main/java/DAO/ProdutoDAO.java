package DAO;

import Model.ProdutoModel;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProdutoDAO {
    private DataBaseConnection connection;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;


    public ProdutoDAO(){
        connection = new DataBaseConnection();
    }

    public Boolean inserirProduto(ProdutoModel produtoDado) {
        try {
            String query = "INSERT INTO produto (id_produto, nome, preco, descrico) INTO (?, ?, ?, ?)";
            preparedStatement = connection.getConnection().prepareStatement(query);
            preparedStatement.setString(1, produtoDado.getId_produto());
            preparedStatement.setString(2, produtoDado.getNome());
            preparedStatement.setString(3, produtoDado.getPreco());
            preparedStatement.setString(4, produtoDado.getDescrico());
            preparedStatement.execute();
            return this.preparedStatement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public String buscarPorID(ProdutoModel produtoID) {
        try {
            String query = "SELECT nome, preco, descrico FROM produto WHERE id_produto = ?";
            preparedStatement = connection.getConnection().prepareStatement(query);
            preparedStatement.setString(1, produtoID.getId_produto());
            this.resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                return resultSet.getString(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "ID não encontrado";
    }
}
