package DAO;

import Model.CadastrarUsuarioModel;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CadastrarUsuarioDAO {

    private DataBaseConnection connection;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;
    SecretKey chave = Crypto.gerarChave();
    GCMParameterSpec iv = Crypto.gerarIV();

    public CadastrarUsuarioDAO() {
        connection = new DataBaseConnection();
    }

    public boolean inserirDadosUsuario(CadastrarUsuarioModel usuarioDados) {
        try {
            String query = "INSERT INTO usuario (email, nome, cpf, senha) VALUES (?, ?, ?, ?)";
            preparedStatement = connection.getConnection().prepareStatement(query);
            preparedStatement.setString(1, usuarioDados.getEmail());
            preparedStatement.setString(2, usuarioDados.getNome());
            preparedStatement.setString(3, usuarioDados.getCpf());
            preparedStatement.setString(4, Crypto.encriptarDado(usuarioDados.getSenha(), chave, iv));
            preparedStatement.execute();
            return this.preparedStatement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (InvalidAlgorithmParameterException | NoSuchPaddingException | IllegalBlockSizeException |
                 NoSuchAlgorithmException | BadPaddingException | InvalidKeyException e) {
            throw new RuntimeException(e);
        }
        return false;
    }

    public CadastrarUsuarioModel buscaUsuario(String usuarioDados) {
        try {
            String query = "SELECT * FROM usuario WHERE nome = ?";
            preparedStatement = connection.getConnection().prepareStatement(query);
            preparedStatement.setString(1,usuarioDados);
            this.resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                String emailDB = resultSet.getString(1);
                String nomeDB = resultSet.getString(2);
                String cpfDB = resultSet.getString(3);
                String senhaDB = resultSet.getString(4);

                return new CadastrarUsuarioModel(emailDB, nomeDB, cpfDB,senhaDB);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new CadastrarUsuarioModel();
    }
}
