package Model;

public class ProdutoModel {
    private String id_produto;
    private String nome;
    private String preco;
    private String descrico;


    public String getId_produto() {
        return id_produto;
    }

    public void setId_produto(String id_produto) {
        this.id_produto = id_produto;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public String getDescrico() {
        return descrico;
    }

    public void setDescrico(String descrico) {
        this.descrico = descrico;
    }


    public ProdutoModel(String id_produto, String nome, String preco, String descrico) {
        this.id_produto = id_produto;
        this.nome = nome;
        this.preco = preco;
        this.descrico = descrico;
    }

    public ProdutoModel(){

    }


}
