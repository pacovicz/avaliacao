package Controller;

import DAO.CadastrarUsuarioDAO;
import Model.CadastrarUsuarioModel;
import View.CadastrarUsuarioView;

public class CadastrarUsuarioController {

    private CadastrarUsuarioModel cadastrarUsuarioModel;
    private CadastrarUsuarioDAO cadastrarUsuarioDAO;
    private CadastrarUsuarioView cadastrarUsuarioView;

    public CadastrarUsuarioController() {
        cadastrarUsuarioView = new CadastrarUsuarioView();
        cadastrarUsuarioModel = cadastrarUsuarioView.CadastrarUsuarioModel(new CadastrarUsuarioModel());

        cadastrarUsuarioDAO = new CadastrarUsuarioDAO();
        cadastrarUsuarioDAO.inserirDadosUsuario(cadastrarUsuarioModel);

        CadastrarUsuarioModel buscaUsuario = cadastrarUsuarioDAO.buscaUsuario(cadastrarUsuarioModel.getNome());
        cadastrarUsuarioView.mostrarDadosUsuario(buscaUsuario);
    }
}
