package Controller;

import DAO.ProdutoDAO;
import Model.ProdutoModel;
import View.ProdutoView;

public class ProdutoController {
    private ProdutoView produtoView;
    private ProdutoModel produtoModel;
    private ProdutoDAO produtoDAO;

    public ProdutoController(){
        produtoView = new ProdutoView();
        produtoModel = produtoView.cadastrarProduto(new ProdutoModel());

        produtoDAO = new ProdutoDAO();
        produtoDAO.buscarPorID(produtoModel);
        produtoView.mostrarInformacaoProduto(produtoModel);
    }
}
