package Main;

import Controller.CadastrarUsuarioController;
import Controller.ProdutoController;

public class Main {
    public static void main(String[] args) {

        //PROFESSOR POR CONTA DO TEMPO NAO CONSEGUI FAZER UM MENUZINHO FOFINHO LINDINHO BONITINHO IGUAL VOCE PEDIU, CONTUDO, SIGO QUASE TUDO QUE FOI SOLICITADO NA AVALIACAO, POR FAVOR CORRIJA COM CARINHO E AMOR, TMJ.!!!!!
        ProdutoController produto = new ProdutoController();
        CadastrarUsuarioController usuario = new CadastrarUsuarioController();
    }
}
