package View;

import Model.CadastrarUsuarioModel;
import java.util.Scanner;

public class CadastrarUsuarioView {
    Scanner scanner;

    public CadastrarUsuarioView(){
        this.scanner = new Scanner(System.in);

    }

    public void mostrarDadosUsuario(CadastrarUsuarioModel usuario){
        System.out.println("Nome: "+usuario.getEmail());
        System.out.println("E-mail: "+usuario.getNome());
        System.out.println("CPF: "+usuario.getCpf());
        System.out.println("Senha: "+usuario.getSenha());
    }

    public CadastrarUsuarioModel CadastrarUsuarioModel(CadastrarUsuarioModel usuario) {
        System.out.print("Nome: ");
        usuario.setEmail(scanner.nextLine());

        System.out.print("E-mail: ");
        usuario.setNome(scanner.nextLine());

        System.out.print("CPF: ");
        usuario.setCpf(scanner.nextLine());

        System.out.print("Senha: ");
        usuario.setSenha(scanner.nextLine());

        return usuario;
    }
}
