package View;
import Model.ProdutoModel;
import java.util.Scanner;

public class ProdutoView {
    Scanner scanner;

    public ProdutoView(){
        this.scanner = new Scanner(System.in);
    }

    public void mostrarInformacaoProduto(ProdutoModel produto){
        System.out.println("ID Produto: "+produto.getId_produto());
        System.out.println("Nome: "+produto.getNome());
        System.out.println("Preco: "+produto.getPreco());
        System.out.println("Descricao: "+produto.getDescrico());
    }

    public ProdutoModel cadastrarProduto(ProdutoModel produto) {
        System.out.print("ID Produto: ");
        produto.setId_produto(scanner.nextLine());

        System.out.print("Nome: ");
        produto.setNome(scanner.nextLine());

        System.out.print("Preco: ");
        produto.setPreco(scanner.nextLine());

        System.out.print("Descricao: ");
        produto.setDescrico(scanner.nextLine());
        return produto;
    }

}
